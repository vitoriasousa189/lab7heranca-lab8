import random

class Personagem:
    def __init__(self, nome, vida):
        self.nome = nome
        self.vida = vida

    def tomar_dano(self, valor):
        self.vida -= valor

class Mago(Personagem):
    def __init__(self, nome, vida, mana):
        super().__init__(nome, vida)
        self.mana = float(mana)

    def __str__(self):
        return f"Nome: {self.nome}, Vida: {self.vida}, Mana: {self.mana}"

    def __add__(self, v):
        self.mana += v
        return self.mana

    def __sub__(self, v):
        self.mana = max(0.0, self.mana - v)
        return self.mana

    def __mul__(self, f):
        self.mana *= f
        return self.mana

    def __truediv__(self, v):
        self.mana /= v
        return self.mana

class Barbaro(Personagem):
    def __init__(self, nome, vida, stamina):
        super().__init__(nome, vida)
        self.stamina = float(stamina)
        self.furia = False

    def __str__(self):
        return f"Nome: {self.nome}, Vida: {self.vida}, Stamina: {self.stamina}, Fúria: {self.furia}"

    def __add__(self, v):
        self.stamina += v * 1.5 if self.furia else v
        return self.stamina

    def __sub__(self, v):
        self.stamina -= v
        if self.stamina <= 0:
            self.furia = True
            self.stamina = 5.0
        return self.stamina

    def __mul__(self, f):
        self.stamina *= f
        if self.furia:
            self.vida += 5
        return self.stamina

    def __truediv__(self, v):
        self.stamina /= v
        return self.stamina

print("=== Criação de Personagem ===")
tipo = input("Digite o tipo (Mago ou Barbaro): ").strip().capitalize()
nome = input("Digite o nome do personagem: ")
vida = int(input("Digite a vida inicial: "))

if tipo == "Mago":
    mana = float(input("Digite a mana inicial: "))
    p = Mago(nome, vida, mana)
elif tipo == "Barbaro":
    stamina = float(input("Digite a stamina inicial: "))
    p = Barbaro(nome, vida, stamina)
else:
    print("Tipo inválido!")
    exit()

while True:
    print("\n=== MENU ===")
    print("1 - Tomar poção simples (+5)")
    print("2 - Tomar poção especial (*1.5)")
    print("3 - Ataque básico (-2)")
    print("4 - Ataque especial (/2)")
    print("5 - Sair")

    op = input("Escolha uma opção: ")

    if op == "1":
        p + 5
    elif op == "2":
        p * 1.5
    elif op == "3":
        p - 2
    elif op == "4":
        p / 2
    elif op == "5":
        break
    else:
        print("Opção inválida!")
        continue

    dano = random.randint(1, 10)
    p.tomar_dano(dano)
    print(f"\nLevou {dano} de dano!")
    print(p)