class Pessoa:
    def __init__(self, nome, altura):
        self.nome = nome
        self.altura = float(altura)

    def __str__(self):
        return f"Nome: {self.nome}, Altura: {self.altura}"

    def __gt__(self, outra):
        return self.altura > outra.altura

    def __lt__(self, outra):
        return self.altura < outra.altura

qtd = int(input("Quantas pessoas serão cadastradas? "))
pessoas = []

for _ in range(qtd):
    nome = input("Digite o nome: ")
    altura = float(input("Digite a altura: "))
    pessoas.append(Pessoa(nome, altura))

print("\nPessoa mais alta:")
print(max(pessoas))

print("\nPessoa mais baixa:")
print(min(pessoas))

print("\nPessoas ordenadas por altura:")
for p in sorted(pessoas):
    print(p)