class Onibus:
    def __init__(self, placa, nome_motorista, num_assentos):
        self.placa = placa
        self.nome_motorista = nome_motorista
        self.assentos = [False] * num_assentos

    def __len__(self):
        return len(self.assentos)

    def __getitem__(self, indice):
        if indice < 0 or indice >= len(self.assentos):
            print("Índice inválido!")
            return None
        return self.assentos[indice]

    def __setitem__(self, indice, valor):
        if indice < 0 or indice >= len(self.assentos):
            print("Índice inválido!")
            return
        if not isinstance(valor, bool):
            print("O valor deve ser True ou False!")
            return
        self.assentos[indice] = valor

    def __str__(self):
        total = len(self.assentos)
        ocupados = sum(self.assentos)
        livres = total - ocupados
        return (
            f"Ônibus (Placa: {self.placa}) - Motorista: {self.nome_motorista}\n"
            f"Assentos totais: {total}\n"
            f"Assentos ocupados: {ocupados}\n"
            f"Assentos livres: {livres}"
        )

onibus = Onibus("GTM-2830", "Carla Rocha", 10)
print(len(onibus))
onibus[0] = True
print(onibus)