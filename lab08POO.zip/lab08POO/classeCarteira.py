class Carteira:
    def __init__(self, moeda, saldo):
        self.moeda = moeda
        self.saldo = float(saldo)

    def _converter(self, valor_yuan):
        if self.moeda == "USD":
            return valor_yuan * 0.14
        elif self.moeda == "BRL":
            return valor_yuan * 0.85
        return valor_yuan

    def __add__(self, valor_yuan):
        self.saldo += self._converter(valor_yuan)
        return self.saldo

    def __sub__(self, valor_yuan):
        self.saldo -= self._converter(valor_yuan)
        return self.saldo

carteira_usd = Carteira("USD", 10.0)
print(carteira_usd + 50.0)