class Bichinho:
    def __init__(self, nome, humor):
        self.nome = nome
        self.humor = humor

    def brincar(self):
        self.humor += 2
    def mostrar_status(self):
        print(f"Nome: {self.nome}")
        print(f"Humor: {self.humor}")

class CaoRobo(Bichinho):
    def __init__(self, nome, humor, bateria):
        super().__init__(nome, humor)
        self.bateria = bateria

    def carregar_bateria(self, valor):
        self.bateria += valor
    def mostrar_status(self):
        super().mostrar_status()
        print(f"Carga da bateria: {self.bateria}")

class Dragao(Bichinho):
    def __init__(self, nome, humor, fogo):
        super().__init__(nome, humor)
        self.fogo = fogo

    def soltar_fogo(self):
        self.fogo += 1
    def mostrar_status(self):
        super().mostrar_status()
        print(f"Nivel do fogo: {self.fogo}")

print("=== Cao Robo ===")
c = CaoRobo("Robozinho", 4, 30)
c.brincar()
c.carregar_bateria(20)
c.mostrar_status()

print("\n=== Dragao ===")
d = Dragao("Foguinho", 2, 1)
d.brincar()
d.soltar_fogo()
d.mostrar_status()