class Conta:
    def __init__(self, saldo):
        self._saldo = float(saldo)

    def depositar(self, valor):
        self._saldo += valor

    def sacar(self, valor):
        if self._saldo >= valor:
            self._saldo -= valor

class Poupanca(Conta):
    def __init__(self, saldo, taxaRendimento):
        super().__init__(saldo)
        self.__taxaRendimento = float(taxaRendimento)

    def render(self):
        self._saldo += self._saldo * (self.__taxaRendimento / 100)

class ContaEspecial(Conta):
    def __init__(self, saldo, limite):
        super().__init__(saldo)
        self.__limite = float(limite)

    def sacar(self, valor):
        if valor <= (self._saldo + self.__limite):
            if valor <= self._saldo:
                self._saldo -= valor
            else:
                valor -= self._saldo
                self._saldo = 0.0
                self.__limite -= valor